# flask-multiple-file-upload

Small demo app for uploading multiple files with Flask, Flask-Uploads, and Flask-Dropszone

Install dependencies

`pip install flask flask-uploads flask-dropzone`

and run

`export FLASK_APP=app.py`

`flask run`
